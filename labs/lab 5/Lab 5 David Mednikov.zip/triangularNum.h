/************************************************************************
** Program name: CS162 Lab 5
** Author: David Mednikov
** Date: 02/09/17
** Description: This is the header file for the triangularNum() method.
************************************************************************/

#ifndef TRIANGULAR_NUM
#define TRIANGULAR_NUM

int triangularNum(int n); // prototype for function, takes an int as a paramter

#endif